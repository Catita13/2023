function refreshPage() {
    window.location.reload();
}